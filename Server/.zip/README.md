# Node Express api, with passport jwt authentication and sequelize ORM.

This is an example api I made for a school project, using json web tokens to authenticate users and using sequelize to query the database
