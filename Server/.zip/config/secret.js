//  Author: Mohammad Jihad Hossain
//  Create Date: 02/05/2019
//  Modify Date: 02/05/2019
//  Description: Main entry file for rest api project for ECL E-Commerce Forum

module.exports = {
  port: process.env.PORT || 9000,
  secretKey: 'Mashrur@Dev',
}
